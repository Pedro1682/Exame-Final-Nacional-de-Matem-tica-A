

function setup() {

  applet.inject("ggb-element")

}





